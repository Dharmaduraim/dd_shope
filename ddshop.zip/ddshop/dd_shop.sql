-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2025 at 07:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dd_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `created_at`) VALUES
(1, 'Mobile', '2025-08-21 09:46:26'),
(2, 'T-Shirts', '2025-08-21 09:46:26'),
(3, 'Shirts', '2025-08-21 09:46:26'),
(4, 'Tv', '2025-08-21 09:46:26'),
(5, 'Watch', '2025-08-21 09:46:26'),
(6, 'Bags', '2025-08-21 09:46:26');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_category` varchar(100) NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `product_date` date NOT NULL,
  `product_descryption` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `product_category`, `product_image`, `product_price`, `product_date`, `product_descryption`) VALUES
(1, 'iPhone 15', 'Mobile', 'iphone15.jpg', '80000', '2025-08-21', 'Latest Apple iPhone 15 smartphone'),
(2, 'Samsung Galaxy S24', 'Mobile', 's24.jpg', '65000', '2025-08-21', 'Powerful Samsung Galaxy S24 with AMOLED display'),
(3, 'Rolex Watch', 'Watch', 'rolex.jpg', '120000', '2025-08-21', 'Luxury Rolex wrist watch'),
(4, 'Casio G-Shock', 'Watch', 'gshock.jpg', '9000', '2025-08-21', 'Stylish and durable G-Shock watch'),
(5, 'Formal Shirt', 'Shirt', 'formal.jpg', '1200', '2025-08-21', 'Slim fit white formal shirt'),
(6, 'Casual T-Shirt', 'T-Shirts', 'download_(3)6.jpg', '8000', '2025-08-21', 'Comfortable cotton T-shirt'),
(11, 'Men | School College Bag for Man', 'Bags', '1755848574_bag.jpg', '1500', '2025-08-22', 'Buy Half Moon Laptop Bag for Men | Backpack for'),
(12, 'Panasonic 80 cm (32 inches) HD Ready Smart LED Google', 'Tv', '1755848673_tv.jpg', '15499', '2025-08-22', 'Resolution : HD (1366 x 768) Resolution | Refresh Rate : 60 Hertz\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `user_register`
--

CREATE TABLE `user_register` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `user_type` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_register`
--

INSERT INTO `user_register` (`id`, `name`, `email`, `password`, `date`, `user_type`) VALUES
(1, 'asd', 'rosekmih@yopmail.com', '12345', '2025-08-20', 1),
(4, 'Dharmadurai', 'dharmaduraim0605@gmail.com', '12345', '2025-08-21', 1),
(5, 'admin', 'admin@gmail.com', 'admin', '2025-08-21', 0),
(6, 'kumar', 'kumar@gmail.com', 'kumar', '2025-08-22', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_register`
--
ALTER TABLE `user_register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user_register`
--
ALTER TABLE `user_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
